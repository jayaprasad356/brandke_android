package com.kapp.bharat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kapp.bharat.Adapter.WalletRecyclerAdapter;
import com.kapp.bharat.Models.WalletRecyclerModel;
//import com.kapp.bharat.databinding.ActivityBeneficiaryBinding;

import java.util.ArrayList;
import java.util.Objects;

public class BeneficiaryActivity extends AppCompatActivity {
//    private ActivityBeneficiaryBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        binding = ActivityBeneficiaryBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());
//        walletRecyclerModelArrayList = new ArrayList<>();
//        walletRecyclerModelArrayList.add(new WalletRecyclerModel("1234567890",
//                "12345690",
//                "567890",
//                "2345679",
//                "67890",
//                "gsjadjgd",
//                "5678989"));
//        walletRecyclerModelArrayList.add(new WalletRecyclerModel("1234567890",
//                "12345690",
//                "567890",
//                "2345679",
//                "67890",
//                "gsjadjgd",
//                "5678989"));
//        walletRecyclerModelArrayList.add(new WalletRecyclerModel("1234567890",
//                "12345690",
//                "567890",
//                "2345679",
//                "67890",
//                "gsjadjgd",
//                "5678989"));
//        walletRecyclerModelArrayList.add(new WalletRecyclerModel("1234567890",
//                "12345690",
//                "567890",
//                "2345679",
//                "67890",
//                "gsjadjgd",
//                "5678989"));
//        walletRecyclerModelArrayList.add(new WalletRecyclerModel("1234567890",
//                "12345690",
//                "567890",
//                "2345679",
//                "67890",
//                "gsjadjgd",
//                "5678989"));
//        walletRecyclerAdapter = new WalletRecyclerAdapter(this,walletRecyclerModelArrayList);
//        if(Objects.requireNonNull(binding.etAccountNumber.getText()).toString().equals("")) {
//            binding.etAccountNumber.setError("Enter Account Number");
//        }else if(Objects.requireNonNull(binding.etAddress.getText()).toString().equals("")) {
//            binding.etAddress.setError("Enter Address");
//        }else if(Objects.requireNonNull(binding.etBankId.getText()).toString().equals("")) {
//            binding.etBankId.setError("Enter Bank Id");
//        }else if(Objects.requireNonNull(binding.etBeneId.getText()).toString().equals("")) {
//            binding.etBeneId.setError("Enter Bene Id");
//        }else if(Objects.requireNonNull(binding.etBeneName.getText()).toString().equals("")) {
//            binding.etBeneName.setError("Enter Bene name");
//        }else if(Objects.requireNonNull(binding.etDob.getText()).toString().equals("")) {
//            binding.etDob.setError("Enter Dob to Continue");
//        }else if(Objects.requireNonNull(binding.etEmail.getText()).toString().equals("")) {
//            binding.etEmail.setError("Enter Email ");
//        }else if(Objects.requireNonNull(binding.etPincode.getText()).toString().equals("")) {
//            binding.etPincode.setError("Enter PinCode");
//        }else {
//            Login();
//        }
    }

    private void Login() {

    }
}