package com.kapp.bharat.Models;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kapp.bharat.R;

public class GiftActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift);
    }
}