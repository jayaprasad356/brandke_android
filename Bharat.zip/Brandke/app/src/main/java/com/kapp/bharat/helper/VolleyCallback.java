package com.kapp.bharat.helper;

public interface VolleyCallback {
    void onSuccess(boolean result, String message);
    //void onSuccessWithMsg(boolean result, String message);

}

